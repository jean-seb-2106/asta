## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(asta)
library(skimr)
library(tidymodels)
library(ggthemes)
library(ranger)
library(kknn)

## -----------------------------------------------------------------------------
# Grandile
# data <- grandile   #changer la base de données ("vins","grandile")
# data <- data %>% rename(target = PAUVRE) %>%
#   select(-starts_with("LIB")) %>%
#   select(-IDENT) %>%
#   mutate(target = as.factor(target))

#vins
data <- vins %>% rename(target = quality)

## -----------------------------------------------------------------------------
#paramètres



part_training <- 0.6 #proportion du découpage aléatoire en training et test
part_validation <- 0.2
var_strata <- "target" #variable de stratification : souvent la variable target

# set.seed(123)
#Découpage en training et en test (ancien découpage)
# data_split <- rsample::initial_split(data,
                                     # strata = .data[[var_strata]],
                                     # prop = part_training)
data_split <- initial_validation_split(data,strata = .data[[var_strata]],prop = c(part_training,part_validation))
# data_split <- initial_validation_split(data,strata = all_of(var_strata))

train_data <- training(data_split) #le fichier d'entraînement
test_data <- testing(data_split) #le fichier de test
valid_data <- validation(data_split)
train_valid_data <- train_data %>% bind_rows(valid_data)

# skim(train_valid_data)
# skim(test_data)


## -----------------------------------------------------------------------------
#################### 1 - Recettes #####################################----------------

#1 - Création de la recette : on met toutes les variables dans un premier temps
#Voulez vous retirer des variables du modèle ? (liste des variables)
#Voulez-vous centrer réduire les variables ? (oui/non)

#Modèle avec toutes les variables
rec1 <- 
  recipe(target ~ ., data = train_valid_data) 

#Modèle avec deux variables en moins
rec2 <- 
  recipe(target ~ ., data = train_valid_data) %>% 
  step_rm(c(fixed.acidity,volatile.acidity))

#Modèle avec toutes les variables centrées réduites
rec3 <- 
  recipe(target ~ ., data = train_valid_data) %>%
  step_normalize(all_numeric_predictors()) 
# %>% step_dummy(all_nominal_predictors()) %>% #: pour transformer les variables nominales en indicatrices
# %>% update_role(flight, time_hour, new_role = "ID") %>% #: pour retirer des variables du modèle
# %>%step_normalize(all_numeric_predictors()) #pour centrer réduire
# %>% step_zv() #pour enlever les variables avec une seules valeur
# %>% step_rm() #removes variables
# %>% step_impute_mode() #imputation des valeurs manquantes avec le mode
# %>% step_impute_mean() #imputation des valeurs manquates avec la moyenne
# %>% step_clean_names #nettoyer le nom des variables

#Recette pour grandile (vin n'a pas de qualitatives)
rec4 <- 
  recipe(target ~ ., data = train_valid_data) %>%
  # step_rm(all_nominal_predictors())   %>% 
  step_normalize(all_numeric_predictors()) %>%
  # step_string2factor(target) %>% 
  # step_rm(IDENT) %>% 
  step_dummy(all_nominal_predictors()) 

#la recette choisie parmi les recettes ci-dessous quand on clique sur validé
rec <- rec4 #paramètre à changer pour changer de recette
rm(rec1,rec2,rec3,rec4)#pour nettoyer l'environnement

## -----------------------------------------------------------------------------
data_rec <- bake(prep(rec),new_data = NULL)
skim(data_rec)

## -----------------------------------------------------------------------------

##############         2 - Modèles      ########################-----------------

#2 - Choix de l'algorithme :

#2-1 la regression logistique
mod_lr <- 
  logistic_reg() %>% 
  set_engine("glm")

#2-2 la forêt aléatoire
#Les paramètres de la forêt aléatoire : 
# trees nombre d'arbres trees
# Nombre de variables pour chaque arbre
mod_rf <- 
  rand_forest(trees = 1000,
              mtry = 3,
              min_n = NULL) %>% 
  set_engine("ranger") %>% 
  set_mode("classification")


#3-3 l'arbre de décision

mod_tree <- 
  mod_tree <- 
  decision_tree(
    cost_complexity = 0.001,
    tree_depth = 7,
    min_n = NULL
  ) %>%
  set_engine("rpart") %>%
  set_mode("classification")


# mod_tree <- 
#   decision_tree(
#     cost_complexity = tune(),
#     tree_depth = tune(),
#     min_n = NULL
#   ) %>% 
#   set_engine("rpart") %>% 
#   set_mode("classification")
# #Hyper-paramètres à tester, généré automatiquement par grid regular
# grid_tree <- grid_regular(cost_complexity(),
#                           tree_depth(),
#                           levels = 5)
#Je teste 25 combinaisons d'hyper paramètres pour trouver le meilleur arbre

#3-4 KNN
mod_knn <- 
  nearest_neighbor(
    neighbors = 3
  ) %>% 
  set_engine("kknn") %>% 
  set_mode("classification")


#3-5 la regression lasso
mod_lasso <- 
  logistic_reg(penalty = 0.001, 
               mixture = 1) %>% 
  set_engine("glmnet")
#lasso grid : 30 hyper-paramètres à tester
grid_lasso <- tibble(penalty = 10^seq(-4, -1, length.out = 30))

#3-4 la regression ridge
mod_ridge <- 
  logistic_reg(penalty = tune(), 
               mixture = 0) %>% 
  set_engine("glmnet")
#ridge grid : 30 hyper-paramètres à tester
grid_ridge <- tibble(penalty = 10^seq(-4, -1, length.out = 30))

#SVM : machine à support de vecteur
mod_svm <- svm_rbf(mode = "classification", 
                     cost = 10, 
                     rbf_sigma = 0.1, 
                     margin = 1) %>%
  set_engine("kernlab")

#On choisit la recette
mod <- mod_lr #paramètre à changer pour changer de modèle

rm(mod_lr,mod_ridge,mod_lasso,mod_rf,mod_tree,mod_knn,mod_svm)

## -----------------------------------------------------------------------------
############# 3 - Workflows     ########################--------------
#3 - Création des workflows

#Workflow sans tuning
wflow <-  workflow() %>% 
  add_model(mod) %>% #ajout du modèle
  add_recipe(rec) #ajout de la recette (transfo de la base initiale)
wflow

## -----------------------------------------------------------------------------
#Ajustement et affichage du résultat du modèle

fit <- wflow %>% fit(data=train_data)

fit %>% 
 extract_fit_parsnip()


## -----------------------------------------------------------------------------
#estimations sur la base d'entraînement

augment(fit,train_data) %>% select(target,starts_with(".pred"))


## -----------------------------------------------------------------------------
predict(fit,new_data = valid_data)
pred_valid <- augment(fit, valid_data) %>% select(target,starts_with(".pred"))
pred1 <- names(pred_valid)[3] #récupération du nom de la variable qui donne la première proba 

roc_plot_valid <- pred_valid %>% 
  roc_curve(truth = target, .data[[pred1]]) %>% 
  autoplot()
roc_plot_valid

#Aire sous la courbe
pred_valid %>% 
  roc_auc(truth = target, .data[[pred1]])

#Accuracy : pourcentage de biens classés
pred_valid %>% 
  accuracy(truth = target, .pred_class)

#Spécificité
pred_valid %>% 
  specificity(truth = target, .pred_class)

#Sensitivité
pred_valid %>% 
  sensitivity(truth = target, .pred_class)

pred_valid %>%
  conf_mat(target, .pred_class) %>%
  autoplot(type="heatmap")
  
  # pluck(1) %>%
  # as_tibble() %>%
  # ggplot(aes(Prediction, Truth, fill = n)) +
  # geom_tile(show.legend = FALSE) +
  # geom_text(aes(label = n), colour = "white", alpha = 1, size = 5) +
  # ggtitle("Table de confusion") +
  # xlab("Classe prédite") + ylab("Classe réelle") +
  # theme_hc() + scale_colour_hc()

## -----------------------------------------------------------------------------
##############Validation croisée##################
# set.seed(345)
nb_folds <- 5
folds <- vfold_cv(train_valid_data,
                  v = nb_folds)#paramétrage de la validation croisée
# 
# Evaluation du modèle avec la validation croisée
metrics <- metric_set(accuracy,recall, precision,roc_auc,sensitivity, specificity)
fit_rs <- wflow %>% fit_resamples(folds,
                                  metrics = metrics,
                                  control = control_resamples(save_pred = TRUE))

nb_rs_metrics <- collect_metrics(fit_rs)
nb_rs_predictions <- collect_predictions(fit_rs)

nb_rs_predictions %>% 
  accuracy(truth = target, .pred_class)

#Dans les infoBoxs
accuracy <- nb_rs_predictions %>% accuracy(truth = target, .pred_class) %>% select(.estimate) %>% round(2) %>% as.character()
sensitivity <- nb_rs_predictions %>% sensitivity(truth = target, .pred_class) %>% select(.estimate) %>% round(2) %>% as.character()
specificity <- nb_rs_predictions %>% specificity(truth = target, .pred_class) %>% select(.estimate) %>% round(2) %>% as.character()

roc_auc <- nb_rs_metrics[nb_rs_metrics$.metric=="roc_auc","mean"] %>% as.character()

##dans le premier renderPlot
fit_rs %>% collect_metrics()
conf_mat_resampled(fit_rs, tidy = FALSE) %>%
  autoplot(type = "heatmap")

##dans le deuxième renderPlot
nb_rs_predictions %>% 
  roc_curve(truth = target, .pred_bon) %>% 
  autoplot()


## -----------------------------------------------------------------------------
#5 - Visualisation du résultat (regression logistique et random forest)

fit_final <- 
  wflow %>% 
  fit(data = train_valid_data) 
  
#6 - Prédiction sur la base de test
pred_testing <- augment(fit_final, test_data) #renvoie une base avec aussi les probas 


#affichage de la courbe ROC
roc_plot_testing <- pred_testing %>% 
  roc_curve(truth = target, .pred_bon) %>% 
  autoplot()
roc_plot_testing

#Aire sous la courbe
pred_testing %>% 
  roc_auc(truth = target, .pred_bon)

#Accuracy : pourcentage de biens classés
pred_testing %>% 
  accuracy(truth = target, .pred_class)

#Spécificité
pred_testing %>% 
  specificity(truth = target, .pred_class)

#Sensitivité
pred_testing %>% 
  sensitivity(truth = target, .pred_class)

pred_testing %>%
  conf_mat(target, .pred_class) %>%
  pluck(1) %>%
  as_tibble() %>%
  ggplot(aes(Prediction, Truth, fill = n)) +
  geom_tile(show.legend = FALSE) +
  geom_text(aes(label = n), colour = "white", alpha = 1, size = 5) +
  ggtitle("Table de confusion") +
  xlab("Classe prédite") + ylab("Classe réelle") +
  theme_hc() + scale_colour_hc()


## -----------------------------------------------------------------------------

data <- ozone %>%
  mutate(target = maxO3) %>%
  select(-maxO3)


# data <- grandile  %>%
#   select(-starts_with("LIB")) %>%
#   mutate(target = REV_DISPONIBLE) %>%
#   select(-IDENT,-REV_DISPONIBLE)




## -----------------------------------------------------------------------------
skim(data)

## -----------------------------------------------------------------------------

part_training <- 0.8
part_validation <- (1-part_training)/2

data_split <- initial_validation_split(data,prop = c(part_training,part_validation)) 

train_data <- training(data_split) #le fichier d'entraînement
test_data <- testing(data_split) #le fichier de test
valid_data <- validation(data_split)
train_valid_data <- train_data %>% bind_rows(valid_data)


## -----------------------------------------------------------------------------

# #Sélection des variables quantis (numériques et integer)
# select_class_df <- function(df,type){
# 
#     names(df[, map_chr(.x = df,.f = class)%in% type])
# 
#     }
# 
# #selection des variables quanti, c'est à dire integer et numeric
# quantis <- select_class_df(data %>% select(-target),c("integer","numeric"))
# 
# 
# #Sélection des variables qualis
# qualis <- select_class_df(data %>% select(-target),c("character"))
# 
# quantis_qualis <- names(data %>% select(-target))


## -----------------------------------------------------------------------------

####Aucune transformation
rec1 <- 
  recipe(target ~ ., data = train_data)

######1seule transfo

#Centrage réduction de toutes les variables quantitatives
rec2 <- rec1 %>%
  step_normalize(all_numeric_predictors()) 

#Imputation des valeurs manquantes avec la moyenne
rec3 <- rec1 %>% 
  step_impute_mean(c(Ne18,Ne15)) 

#enlever des variables (choisir les variables)
rec4 <- rec1 %>% 
  step_rm(T6)

######2transfos (l'ordre importe)

#Imputation des valeurs manquantes PUIS Centrage réduction de toutes les variables 
rec23 <- rec3 %>% 
  step_normalize(all_numeric_predictors())

#centrage réduction de toutes les numériques PUIS imputation des valeurs manquantes
rec32 <- rec2 %>% 
  step_impute_mean(Ne18)

rec <- rec3
rm(rec1,rec2,rec3,rec4,rec23,rec32)

## -----------------------------------------------------------------------------
prep <- prep(rec)
bake <- bake(prep, new_data = NULL)
skim(bake)


## -----------------------------------------------------------------------------
rec

## -----------------------------------------------------------------------------

#modèle de regression linéaire
mod_lr <- linear_reg() %>% 
  set_engine("lm") 

#Modèle arbre (avec CART)
mod_tree <- 
  mod_tree <- 
  decision_tree(
    cost_complexity = 0.001,
    tree_depth = 7,
    min_n = NULL
  ) %>%
  set_engine("rpart") %>%
  set_mode("regression")

#random forest
mod_rf <- rand_forest() %>%
  set_engine("ranger") %>%
  set_mode("regression")

#modèle SVM
mod_svm <- svm_linear() %>%
  set_mode("regression") %>%
  set_engine("LiblineaR")


mod <- mod_tree
rm(mod_lr,mod_rf,mod_svm)

## -----------------------------------------------------------------------------
wflow <- workflow() %>% 
  add_recipe(rec) %>% 
  add_model(mod)
wflow

## -----------------------------------------------------------------------------
fit <- wflow %>% fit(data=train_data)

fit %>% 
 extract_fit_parsnip()


## -----------------------------------------------------------------------------
pred_train <- augment(fit,train_data) %>% select(target,.pred) %>% round(1)
pred_train

## -----------------------------------------------------------------------------
pred_valid <- augment(fit,valid_data) %>% select(target,.pred) %>% round(1)
pred_valid

## -----------------------------------------------------------------------------
#Somme des carrés des résidus (RSS : residual sum of squares)
rss <- sum((pred_valid$.pred - pred_valid$target)^2)


#MSE : erreur quadratique moyenne (mean squared error)
#pour enlever l'effet taille (plus la base est grande, plus le rss est grand)
mse <- rss/nrow(pred_valid)


# RSME : racine carré de la MSE, pour se ramener à l'unité de la variable
rmse <- sqrt(mse)
rmse(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric() %>% round(2)

#LRMSE : log de tout ça pour enlever les effets des ordres de grandeur
rmsle <- sqrt(
  (sum(
    (log(pred_valid$.pred +1) - log(pred_valid$target + 1))^2))/(nrow(pred_valid)
                                                                 )
  )


#Coefficient de détermination
rsq <- rsq(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()

#Coefficient de corrélation linéaire
cor(pred_valid$.pred,pred_valid$target)


#Erreur carré relative
rse <- 1-rsq



tibble(rss,mse,rmse,rmsle,rse,rsq)
rm(rss,mse,rmse,rmsle,rse,rsq)
# mae(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()
# mape(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()

## -----------------------------------------------------------------------------
# set.seed(345)
nb_folds <- 5
folds <- vfold_cv(train_valid_data,
                  v = nb_folds)#paramétrage de la validation croisée
# 
# Evaluation du modèle avec la validation croisée
metrics <- metric_set(rmse,rsq,mae, mape)
fit_rs <- wflow %>% fit_resamples(folds,
                                  metrics = metrics,
                                  control = control_resamples(save_pred = TRUE))

nb_rs_metrics <- collect_metrics(fit_rs)
nb_rs_predictions <- collect_predictions(fit_rs)


nb_rs_metrics


## -----------------------------------------------------------------------------
fit_final <- 
  wflow %>% 
  fit(train_valid_data)



## -----------------------------------------------------------------------------
pred_testing <- augment(fit_final, test_data) %>% select(target,.pred)
pred_testing

## -----------------------------------------------------------------------------
rss <- sum((pred_valid$.pred - pred_valid$target)^2)
mse <- rss/nrow(pred_valid)
rmse <- sqrt(mse)
rmlse <- sqrt(
  (sum(
    (log(pred_valid$.pred +1) - log(pred_valid$target + 1))^2))/(nrow(pred_valid)
                                                                 )
  )
rsq <- rsq(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()
rse <- 1-rsq



tibble(rss,mse,rmse,rmlse,rse,rsq)
rm(rss,mse,rmse,rmsle,rse,rsq)
# mae(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()
# mape(pred_valid,target,.pred) %>% select(.estimate) %>% as.numeric()

