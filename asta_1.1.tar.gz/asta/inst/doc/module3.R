## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(asta)
library(dplyr)
library(DT)
library(factoextra)
library(FactoMineR)

## -----------------------------------------------------------------------------
departements %>% datatable(class = "display")
str(departements)

## -----------------------------------------------------------------------------
#paramètres : quel axe affiché en abscisse - réglette de 1 à 6
#             quel axe affiché en ordonnée - réglette de 1 à 6
#             case à cocher pour "chevauchement des labels non/oui" -> option "repel =T/F" à côté du bouton "mettre à jour"

axe1 <- 1 
axe2 <- 2 
repel <- FALSE #case à cocher checkbox
varsupe <- FALSE


## -----------------------------------------------------------------------------
#ACP en gardant jusqu'à 6 composantes principales
res.pca <- PCA(departements, graph=F, ncp=6, quali.sup = "GR_REG")

## -----------------------------------------------------------------------------
#Graphique "Décomposition de l'inertie"
fviz_eig(res.pca, addlabels = TRUE)

## -----------------------------------------------------------------------------
#graphique "Graphe des variables" - axes paramétrables
fviz_pca_var(res.pca, 
             axes=c(axe1,axe2), 
             col.var = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), 
             repel = repel)


## -----------------------------------------------------------------------------
#Graphique "Nuage des individus" - axes paramétrables
fviz_pca_ind(res.pca, 
             axes=c(axe1,axe2), 
             repel = repel, 
             labelsize=3)

## -----------------------------------------------------------------------------
#Graphique "Nuage des individus" - idem, mais avec projection d'une supplémentaire quali (région) + ellipses
fviz_pca_ind(res.pca, 
             axes=c(axe1,axe2), 
             repel = repel, 
             labelsize=3, 
             habillage = "GR_REG", 
             addEllipses = TRUE, 
             ellipse.level=0.9)


